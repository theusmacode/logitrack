import { useState } from 'react'
import './App.css'

type Page = 'dashboard' | 'products' | 'scanner' | 'movements'

function App() {
  const [page, setPage] = useState<Page>('dashboard')

  const menuItems = [
    { id: 'dashboard' as Page, icon: '▦', label: 'Dashboard' },
    { id: 'products' as Page, icon: '📦', label: 'Produtos' },
    { id: 'scanner' as Page, icon: '⌗', label: 'Scanner QR' },
    { id: 'movements' as Page, icon: '↕', label: 'Movimentações' },
  ]

  return (
    <div className="app">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon">LT</div>

          <div>
            <h1>LogiTrack</h1>
            <span>Controle logístico</span>
          </div>
        </div>

        <nav>
          {menuItems.map((item) => (
            <button
              key={item.id}
              className={`menu-item ${page === item.id ? 'active' : ''}`}
              onClick={() => setPage(item.id)}
            >
              <span className="menu-icon">{item.icon}</span>
              <span>{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="sidebar-footer">
          <div className="status-dot" />
          <div>
            <strong>Sistema online</strong>
            <span>Supabase conectado</span>
          </div>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div>
            <span className="breadcrumb">LogiTrack /</span>
            <h2>
              {page === 'dashboard' && 'Dashboard'}
              {page === 'products' && 'Produtos'}
              {page === 'scanner' && 'Scanner QR'}
              {page === 'movements' && 'Movimentações'}
            </h2>
          </div>

          <div className="topbar-right">
            <div className="connection">
              <span className="status-dot" />
              Conectado
            </div>

            <div className="avatar">M</div>
          </div>
        </header>

        <section className="content">
          {page === 'dashboard' && <Dashboard />}
          {page === 'products' && <Products />}
          {page === 'scanner' && <Scanner />}
          {page === 'movements' && <Movements />}
        </section>
      </main>
    </div>
  )
}

function Dashboard() {
  return (
    <>
      <div className="welcome">
        <div>
          <span className="eyebrow">VISÃO GERAL</span>
          <h3>Controle seu estoque de forma inteligente.</h3>
          <p>
            Acompanhe produtos, movimentações e níveis de estoque em um só lugar.
          </p>
        </div>

        <button className="primary-button">
          + Cadastrar produto
        </button>
      </div>

      <div className="stats">
        <StatCard
          label="Total de produtos"
          value="1"
          detail="Produtos cadastrados"
          icon="📦"
        />

        <StatCard
          label="Estoque total"
          value="20"
          detail="Unidades disponíveis"
          icon="▣"
        />

        <StatCard
          label="Estoque baixo"
          value="0"
          detail="Produtos precisam de atenção"
          icon="⚠"
        />

        <StatCard
          label="Movimentações"
          value="0"
          detail="Entradas e saídas"
          icon="↕"
        />
      </div>

      <div className="dashboard-grid">
        <div className="panel">
          <div className="panel-header">
            <div>
              <span className="eyebrow">ESTOQUE</span>
              <h3>Produtos recentes</h3>
            </div>

            <button className="text-button">Ver todos →</button>
          </div>

          <div className="product-row">
            <div className="product-icon">📦</div>

            <div className="product-info">
              <strong>Caixa de Componentes</strong>
              <span>LT-00001 • Prateleira B3</span>
            </div>

            <div className="quantity">
              <strong>20</strong>
              <span>unidades</span>
            </div>

            <span className="stock-badge">Em estoque</span>
          </div>
        </div>

        <div className="panel">
          <div className="panel-header">
            <div>
              <span className="eyebrow">ACESSO RÁPIDO</span>
              <h3>Ações</h3>
            </div>
          </div>

          <div className="quick-actions">
            <button>
              <span>📦</span>
              Cadastrar produto
            </button>

            <button>
              <span>⌗</span>
              Escanear QR Code
            </button>

            <button>
              <span>↕</span>
              Registrar movimentação
            </button>
          </div>
        </div>
      </div>
    </>
  )
}

function Products() {
  return (
    <div className="page-placeholder">
      <div className="placeholder-icon">📦</div>
      <h3>Produtos</h3>
      <p>
        Aqui ficará o cadastro e gerenciamento de todos os produtos.
      </p>

      <button className="primary-button">
        + Cadastrar produto
      </button>
    </div>
  )
}

function Scanner() {
  return (
    <div className="page-placeholder">
      <div className="placeholder-icon">⌗</div>
      <h3>Scanner QR Code</h3>
      <p>
        Aqui ficará o leitor de QR Code usando a câmera do celular.
      </p>

      <button className="primary-button">
        Abrir câmera
      </button>
    </div>
  )
}

function Movements() {
  return (
    <div className="page-placeholder">
      <div className="placeholder-icon">↕</div>
      <h3>Movimentações</h3>
      <p>
        Aqui ficará o histórico de entradas e saídas do estoque.
      </p>
    </div>
  )
}

type StatCardProps = {
  label: string
  value: string
  detail: string
  icon: string
}

function StatCard({ label, value, detail, icon }: StatCardProps) {
  return (
    <div className="stat-card">
      <div className="stat-top">
        <span>{label}</span>
        <div className="stat-icon">{icon}</div>
      </div>

      <strong>{value}</strong>

      <small>{detail}</small>
    </div>
  )
}

export default App